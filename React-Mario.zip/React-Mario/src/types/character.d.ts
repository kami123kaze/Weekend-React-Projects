 declare type Character = {
  x: number;
  y: number;
  velocityY: number;
  isJumping: boolean;
  img: HTMLImageElement;
  imgWidth: number;
  imgHeight: number;
  scale: number;
};