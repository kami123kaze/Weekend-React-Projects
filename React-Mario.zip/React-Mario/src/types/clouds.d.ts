
declare type Cloud = {
  x: number;
  y: number;
  scale: number;
  speed: number;
};

