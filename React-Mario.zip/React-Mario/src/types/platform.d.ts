declare type platform = {
    x:number,
    y:number,
    length:number,
    width:number
}